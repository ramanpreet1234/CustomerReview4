//
//  LoginVC.swift
//  CustomerReview
//
//  Created by MacStudent on 2018-08-15.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class LoginVC: UIViewController {

    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        if let email = UserDefaults.standard.value(forKey: "email"){
            txtEmail.text = email as? String
        }
        
        if let password = UserDefaults.standard.string(forKey: txtEmail.text!){
            txtPassword.text = password
        }
        // Do any additional setup after loading the view.
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func btnSignUp(_ sender: UIButton) {
        let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let signUpVC = mainSB.instantiateViewController(withIdentifier: "SignUpScene")
        navigationController?.pushViewController(signUpVC, animated: true)
    }
    
    
    @IBAction func btnSignIn(_ sender: UIButton) {
        if validateUser(){
            let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            
        let homeVC = mainSB.instantiateViewController(withIdentifier: "HomeScene")
        //            self.present(homeVC, animated: true, completion: nil)
        navigationController?.pushViewController(homeVC, animated: true)
        
    }
    else {
    //display alert message
    let infoAlert = UIAlertController(title: "User Account", message: "Invalid Email and/or Password", preferredStyle: .alert)
    infoAlert.addAction(UIAlertAction(title: "Retry", style: .default, handler: nil))
    //            infoAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
    //            infoAlert.addAction(UIAlertAction(title: "Don't bother me", style: .destructive, handler: nil))
    //            infoAlert.addAction(UIAlertAction(title: "Oh really !!", style: .default, handler: nil))
    
    self.present(infoAlert, animated: true, completion: nil)
    }

    }
func validateUser() -> Bool{
    if txtEmail.text == "test" && txtPassword.text == "test"{
        return true
    }else{
        return false
    }
  }
}
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */


