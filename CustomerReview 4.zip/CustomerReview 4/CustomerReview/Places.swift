//
//  Places.swift
//  CustomerReview
//
//  Created by MacStudent on 2018-08-11.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Places{
    static var titles : [String] = ["Restaurants","Hotels","Tourist Attraction"]
    
//    static var des : [String] = ["Co-owned by a Top Chef Canada winner, this bustling spot offers a daily menu of seasonal cuisine",
//    "Inventive tasting menus emphasizing local ingredients in a refined space with a secluded courtyard",
//    "Casual chain outpost preparing personalized thin-crust pizzas ready to eat in about 3 minutes",
//    "Flame-seared sushi is the specialty at this Japanese fine-dining destination with soaring ceilings",
//    "French tasting menu served in stylish, serene surrounds atop a Victorian building"]
   
    static var images : [String] = ["Restaurants","Hotels","Tourist Attraction"]
    
}
