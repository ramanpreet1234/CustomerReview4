//
//  Description.swift
//  CustomerReview
//
//  Created by MacStudent on 2018-08-16.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Description {
    static var img : [String] = ["Richmond","George","Blaze","Miku","Alo"]
    static var restaurants : [String] = ["Richmond","George","Blaze","Miku","Alo"]
    static var restaurantsDescription : [String] = ["Co-owned by a Top Chef Canada winner, this bustling spot offers a daily menu of seasonal cuisine",
    "Inventive tasting menus emphasizing local ingredients in a refined space with a secluded courtyard",
    "Casual chain outpost preparing personalized thin-crust pizzas ready to eat in about 3 minutes",
    "Flame-seared sushi is the specialty at this Japanese fine-dining destination with soaring ceilings",
    "French tasting menu served in stylish, serene surrounds atop a Victorian building"]
}
