//
//  HotelDes.swift
//  CustomerReview
//
//  Created by MacStudent on 2018-08-17.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Hotel{
    static var Name : [String] = ["Hilton","Bondplace","Doubletree","Delta","Westinprince"]
    
    static var Des : [String] =  ["Warm rooms & suites in an upscale lodging with lively dining, an indoor/outdoor pool & a gym",
    "Minimalist hotel offering bright, chic rooms plus a casual restaurant & an exercise room",
    "Modern hotel offering streamlined rooms & suites, plus laid-back dining, an indoor pool & a sauna",
    "Casual hotel offering modern rooms, plus an atrium with a saltwater pool, & a Japanese restaurant",
    "Contemporary property with 3 restaurants & a lounge/bar, plus a seasonal outdoor pool"]
    
    static var Image : [String] = ["Hilton","Bondplace","Doubletree","Delta","Westinprince"]
    
}
